import collections.abc
import iris.IRISIterator
import iris.IRISGlobalNodeView

class BEFOREFIRST(object):
	pass

class AFTERLAST(object):
	pass

class _point(object):
	def __init__(self, key, inclusive):
		self._key = key
		self._inclusive = inclusive
	def is_marker(self):
		return isinstance(self._key,BEFOREFIRST) or isinstance(self._key,AFTERLAST)

class IRISGlobalNode(collections.abc.Container, collections.abc.Reversible, collections.abc.Iterable):

	def __init__(self, irisnative, global_name, *subscripts):
		self._irisnative = irisnative
		self._global_name = global_name
		self._subscripts = subscripts
		self._start = _point(BEFOREFIRST(), False)
		self._stop = _point(AFTERLAST(), False)
		self._reversed = False

	def __iter__(self):
		return iris.IRISIterator(iris.IRISGlobalNodeView(self, iris.IRISIterator.VIEW_SUBSCRIPTS))

	def __contains__(self, subscript):
		return self._irisnative.isDefined(self._global_name, *self._subscripts, subscript) != 0

	def __getitem__(self, subscript):
		if isinstance(subscript, slice):
			newnode = self._clone()
			step = 1 if subscript.step is None else subscript.step
			if not isinstance(step, int):
				raise TypeError("slice indices must be integers or None")
			if step != 1 and step != -1:
				raise ValueError("slice step can only be 1, -1 or None")
			if step > 0:
				if subscript.start is not None:
					newnode._start = self._max(self._start, _point(subscript.start, True), newnode._reversed)
				else:
					newnode._start = self._start
				if subscript.stop is not None:
					newnode._stop = self._min(self._stop, _point(subscript.stop, False), newnode._reversed)
				else:
					newnode._stop = self._stop
			else:
				newnode._reversed = not self._reversed
				if subscript.start is not None:
					newnode._start = self._max(self._stop, _point(subscript.start, True), newnode._reversed)
				else:
					newnode._start = self._stop
				if subscript.stop is not None:
					newnode._stop = self._min(self._start, _point(subscript.stop, False), newnode._reversed)
				else:
					newnode._stop = self._start
			return newnode
		else:
			iris_value = self._irisnative.get(self._global_name, *self._subscripts, subscript)
			if iris_value == None:
				raise KeyError("<UNDEFINED>")
			return iris_value

	def __setitem__(self, subscript, value):
		self._irisnative.set(value, self._global_name, *self._subscripts, subscript)

	def __reversed__(self):
		newnode = self._clone()
		newnode._reversed = not self._reversed
		newnode._start = self._stop
		newnode._stop = self._start
		return newnode.__iter__()

	def __delitem__(self, subscript):
		self._irisnative.kill(self._global_name, *self._subscripts, subscript)

	def get(self, keyname, value):
		iris_value = self._irisnative.get(self._global_name, *self._subscripts, keyname)
		return value if iris_value == None else iris_value

	def node(self, subscript):
		return self._irisnative.node(self._global_name, *self._subscripts, subscript)

	def keys(self):
		return iris.IRISGlobalNodeView(self, iris.IRISIterator.VIEW_SUBSCRIPTS)

	def subscripts(self):
		return iris.IRISGlobalNodeView(self, iris.IRISIterator.VIEW_SUBSCRIPTS)

	def values(self):
		return iris.IRISGlobalNodeView(self, iris.IRISIterator.VIEW_VALUES)

	def items(self):
		return iris.IRISGlobalNodeView(self, iris.IRISIterator.VIEW_ITEMS)

	def nodes(self):
		return iris.IRISGlobalNodeView(self, iris.IRISIterator.VIEW_NODES)

	def nodesitems(self):
		return iris.IRISGlobalNodeView(self, iris.IRISIterator.VIEW_NODEITEMS)

	def _clone(self):
		newnode = IRISGlobalNode(self._irisnative, self._global_name, *self._subscripts)
		newnode._start = self._start
		newnode._stop = self._stop
		newnode._reversed = self._reversed
		return newnode

	@classmethod
	def _min(cls, X, Y, reversed):
		if X._key == Y._key:
			return X._inclusive if X._inclusive == Y._inclusive else reversed
		if cls._follows(X._key, Y._key) == reversed:
			return X
		else:
			return Y

	@classmethod
	def _max(cls, X, Y, reversed):
		if X._key == Y._key:
			return X._inclusive if X._inclusive == Y._inclusive else reversed
		if cls._follows(X._key, Y._key) == reversed:
			return Y
		else:
			return X

	@staticmethod
	def _follows(X, Y):
		if X == Y:
			return False
		if isinstance(X, BEFOREFIRST):
			return False
		if isinstance(X, AFTERLAST):
			return True
		if isinstance(Y, BEFOREFIRST):
			return True
		if isinstance(Y, AFTERLAST):
			return False
		if not isinstance(X,int) and not isinstance(X,float) and not isinstance(X,str):
			raise TypeError("subscript can only be int, float or str")
		if not isinstance(Y,int) and not isinstance(Y,float) and not isinstance(Y,str):
			raise TypeError("subscript can only be int, float or str")
		is_X_number = not isinstance(X,str)
		is_Y_number = not isinstance(Y,str)
		if is_X_number and is_Y_number:
			return X>Y
		elif is_X_number:
			return False
		elif is_Y_number:
			return True
		else:
			return sorted([X,Y])[1]==X

	@staticmethod
	def _point(key, inclusive):
		return _point(key, inclusive)

	def slice_state(self):
		'''
Returns a formatted string that describes the state of slicing in the IRISGlobalNode object.

slice_state()

IRISGLobalNode object can be sliced to limit the subscript traversing range.

node[start:stop:step]

Slicing results in a new IRISGlobalNode object with the newly sliced range - traversing from start (inclusive) to stop (exclusive).
step can be 1 or -1, meaning traversing in forward direction or in reversed direction.

The formatted string uses the standard mathematical notation of bracketing.
Square brackets, [], are used to denote closed intervals with inclusive endpoints.
Parentheses, (), are used to denote open intervals with exclusive endpoints
For example, "[ 3 >>> 7 )" means from 3 to 7, forward direction, inclusive of 3 but exclusive of 7. This is what you will get with a simple slicing of node[3:7]
"[ 1 <<< 9 ]" means from 9 to 1, in reversed direction, inclusive on both ends.

Return Value
------------
Returns slice state.
		'''
		if self._reversed:
			left_sign = "[ " if self._stop._inclusive else "( "
			left_key = "None" if self._stop.is_marker() else str(self._stop._key)
			arrows = " <<< "
			right_key = "None" if self._start.is_marker() else str(self._start._key)
			right_sign = " ]" if self._start._inclusive else " )"
		else:
			left_sign = "[ " if self._start._inclusive else "( "
			left_key = "None" if self._start.is_marker() else str(self._start._key)
			arrows = " >>> "
			right_key = "None" if self._stop.is_marker() else str(self._stop._key)
			right_sign = " ]" if self._stop._inclusive else " )"
		return left_sign + left_key + arrows + right_key + right_sign


