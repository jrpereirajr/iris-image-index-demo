import iris._DBList
import iris._ListReader
import iris._ListWriter
import iris.IRIS

class IRISList(object):

	def __init__(self, buffer = None, locale = "latin-1", is_unicode = True):
		self._list_data = []
		self._locale = locale
		self._is_unicode = is_unicode
		try:
			if buffer == None:
				return
			if type(buffer) == iris.IRISList:
				buffer = buffer.getBuffer()
			if type(buffer) == bytes or type(buffer) == bytearray:
				list_reader = iris._ListReader._ListReader(buffer, locale)
				while not list_reader._is_end():
					value = list_reader._get(True)
					if value is None and list_reader.list_item.type !=  iris._DBList._DBList.ITEM_UNDEF:
						value = bytes()
					self._list_data.append(value)
				return
		except Exception as ex:
			pass
		raise Exception("data is not valid for IRISList format")

	def get(self, index):
		raw_data = self._list_data[index-1]
		if type(raw_data) == iris.IRISList:
			raw_data = raw_data.getBuffer()
		if type(raw_data) == bytes:
			return iris.IRIS._convertToString(raw_data, iris.IRIS.MODE_LIST, self._locale)
		return raw_data

	def getBoolean(self, index):
		raw_data = self._list_data[index-1]
		if type(raw_data) == iris.IRISList:
			raw_data = raw_data.getBuffer()
		return iris.IRIS._convertToBoolean(raw_data, iris.IRIS.MODE_LIST, self._locale)

	def getBytes(self, index):
		raw_data = self._list_data[index-1]
		if type(raw_data) == iris.IRISList:
			return raw_data.getBuffer()
		return iris.IRIS._convertToBytes(raw_data, iris.IRIS.MODE_LIST, self._locale)

	def getDecimal(self, index):
		raw_data = self._list_data[index-1]
		if type(raw_data) == iris.IRISList:
			raw_data = raw_data.getBuffer()
		return iris.IRIS._convertToDecimal(raw_data, iris.IRIS.MODE_LIST, self._locale)

	def getFloat(self, index):
		raw_data = self._list_data[index-1]
		if type(raw_data) == iris.IRISList:
			raw_data = raw_data.getBuffer()
		return iris.IRIS._convertToFloat(raw_data, iris.IRIS.MODE_LIST, self._locale)

	def getInteger(self, index):
		raw_data = self._list_data[index-1]
		if type(raw_data) == iris.IRISList:
			raw_data = raw_data.getBuffer()
		return iris.IRIS._convertToInteger(raw_data, iris.IRIS.MODE_LIST, self._locale)

	def getString(self, index):
		raw_data = self._list_data[index-1]
		if type(raw_data) == iris.IRISList:
			raw_data = raw_data.getBuffer()
		return iris.IRIS._convertToString(raw_data, iris.IRIS.MODE_LIST, self._locale)

	def getIRISList(self, index):
		raw_data = self._list_data[index-1]
		if type(raw_data) == iris.IRISList or raw_data == None:
			return raw_data
		return iris.IRISList(iris.IRIS._convertToBytes(raw_data, iris.IRIS.MODE_LIST, self._locale), self._locale, self._is_unicode)

	def add(self, value):
		self._list_data.append(self._convertToInternal(value))
		return self

	def set(self, index, value):
		if index>len(self._list_data):
			self._list_data.extend([None]*(index-len(self._list_data)))
		self._list_data[index-1] = self._convertToInternal(value)
		return self

	def _convertToInternal(self, value):
		if type(value) == bytearray:
			return bytes(value)
		if type(value) == iris.IRISList:
			return iris.IRISList(value.getBuffer())
		return value

	def remove(self, index):
		del self._list_data[index-1]
		return self

	def size(self):
		return len(self.getBuffer())

	def count(self):
		return len(self._list_data)

	def clear(self):
		self._list_data = []
		return self

	def equals(self, irislist2):
		if type(irislist2) != iris.IRISList:
			raise TypeError("Argument must be an instance of iris.IRISList")
		if len(self._list_data) != len(irislist2._list_data):
			return False
		for i in range(len(self._list_data)):
			if self.get(i+1) != irislist2.get(i+1):
				return False
		return True

	def __str__(self):
		display = ""
		for i in range(len(self._list_data)):
			raw_data = self._list_data[i]
			if type(raw_data) == iris.IRISList:
				raw_data = raw_data.__str__()
			elif type(raw_data) == bool:
				raw_data = 1 if raw_data else 0
			if type(raw_data) == bytes:
				try:
					one_value = iris.IRISList(raw_data).__str__()
				except Exception:
					one_value = str(raw_data)
			else:
				one_value = str(raw_data)
			display += one_value + ","
		return "$lb(" + display[0:-1] + ")"

	def getBuffer(self):
		list_writer = iris._ListWriter._ListWriter(self._locale, self._is_unicode)
		for i in range(len(self._list_data)):
			if self._list_data[i] == None:
				list_writer._set_undefined()
			elif type(self._list_data[i]) == iris.IRISList:
				buffer = self._list_data[i].getBuffer()
				list_writer._set(buffer)
			else:
				list_writer._set(self._list_data[i])
		return bytes(list_writer._get_buffer())
