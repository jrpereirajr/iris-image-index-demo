import weakref
import iris.IRIS

class IRISObject(object):

	def __init__(self, connection, oref):
		self._connection = connection
		self._iris = iris.IRIS(connection)
		self._oref = oref
		self._closed = False
		self._connection._iris_object_proxy_map[oref] = weakref.ref(self)

	def get(self, property_name):
		return self._iris._execute(object, iris.IRIS.GET_PROPERTY, self, property_name, None)

	def getObject(self, property_name):
		return self._iris._execute(object, iris.IRIS.GET_PROPERTY, self, property_name, None)

	def getBoolean(self, property_name):
		return self._iris._execute(bool, iris.IRIS.GET_PROPERTY, self, property_name, None)

	def getBytes(self, property_name):
		return self._iris._execute(bytes, iris.IRIS.GET_PROPERTY, self, property_name, None)

	def getDecimal(self, property_name):
		return self._iris._execute(decimal.Decimal, iris.IRIS.GET_PROPERTY, self, property_name, None)

	def getFloat(self, property_name):
		return self._iris._execute(float, iris.IRIS.GET_PROPERTY, self, property_name, None)

	def getInteger(self, property_name):
		return self._iris._execute(int, iris.IRIS.GET_PROPERTY, self, property_name, None)

	def getString(self, property_name):
		return self._iris._execute(str, iris.IRIS.GET_PROPERTY, self, property_name, None)

	def getIRISList(self, property_name):
		return self._iris._execute(iris.IRISList, iris.IRIS.GET_PROPERTY, self, property_name, None)

	def set(self, property_name, property_value):
		self._iris._execute(None, iris.IRIS.SET_PROPERTY, self, property_name, None, property_value, honorByReference = False)
		return

	def invoke(self, method_name, *args):
		return self._iris._execute(object, iris.IRIS.VALUE_METHOD, self, method_name, args)

	def invokeObject(self, method_name, *args):
		return self._iris._execute(object, iris.IRIS.VALUE_METHOD, self, method_name, args)

	def invokeBoolean(self, method_name, *args):
		return self._iris._execute(bool, iris.IRIS.VALUE_METHOD, self, method_name, args)

	def invokeBytes(self, method_name, *args):
		return self._iris._execute(bytes, iris.IRIS.VALUE_METHOD, self, method_name, args)

	def invokeDecimal(self, method_name, *args):
		return self._iris._execute(decimal.Decimal, iris.IRIS.VALUE_METHOD, self, method_name, args)

	def invokeFloat(self, method_name, *args):
		return self._iris._execute(float, iris.IRIS.VALUE_METHOD, self, method_name, args)

	def invokeInteger(self, method_name, *args):
		return self._iris._execute(int, iris.IRIS.VALUE_METHOD, self, method_name, args)

	def invokeString(self, method_name, *args):
		return self._iris._execute(str, iris.IRIS.VALUE_METHOD, self, method_name, args)

	def invokeIRISList(self, method_name, *args):
		return self._iris._execute(iris.IRISList, iris.IRIS.VALUE_METHOD, self, method_name, args)

	def invokeVoid(self, method_name, *args):
		self._iris._execute(None, iris.IRIS.VOID_METHOD, self, method_name, args)
		return

	def close(self):
		if not self._closed:
			with self._connection._lock_closed_oref:
				del self._connection._iris_object_proxy_map[self._oref]
				self._connection._iris_object_proxy_closed.append(self._oref)
				self._closed = True

	def __del__(self):
		if not self._closed:
			self.close()



