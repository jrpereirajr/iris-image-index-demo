import platform

class _GatewayUtility(object):

	@staticmethod
	def getLanguageName():
		return "Python"

	@staticmethod
	def getLanguageVersion():
		return platform.python_version()


