import base64
import getpass
import os
import platform
import socket
import struct
import sys
import threading
import iris._ConnectionInfo
import iris._Constant
import iris._Device
import iris._GatewayException
import iris._IRISOREF
import iris._InStream
import iris._LogFileStream
import iris._OutStream
import iris._PythonGateway
import iris.IRISObject

class IRISConnection():

	CLOSED_PROXY_UPDATE_THRESHOLD = 2
	MESSAGE_HANDSHAKE = b'HS'
	MESSAGE_CONNECT = b'CN'
	MESSAGE_DISCONNECT = b'DC'

	def __init__(self, device, gateway, log_stream):
		self.hostname = ""
		self.port = ""
		self.namespace = ""
		self.timeout = ""
		self.sharedmemory = False
		self.logfile = ""
		self._sequence_number = -1
		self._lock = threading.RLock()
		self._lock_sequence_number = threading.RLock()
		self._lock_closed_oref = threading.RLock()
		self._connection_info = iris._ConnectionInfo._ConnectionInfo()
		self._disable_output_redirect = False
		self._oref_registry = {}
		self._oref_to_class_map = {}
		self._iris_object_proxy_map = {}
		self._iris_object_proxy_closed = []
		self._gateway = gateway
		self._log_stream = log_stream
		if device != None:
			self._device = device
			self._in_message = iris._InStream._InStream(self)
			self._out_message = iris._OutStream._OutStream(self)

	def __del__(self):
		try:
			self.close()
		except:
			pass
		return

	def close(self):
		if self._device != None:
			with self._lock:
				self._out_message.wire._write_header(IRISConnection.MESSAGE_DISCONNECT)
				self._out_message._send(0)
			self._device.close()
			self._device = None
		return

	def isClosed(self):
		return self._device == None

	def isUsingSharedMemory(self):
		return False

	def _connect(self, hostname, port, namespace, username, password, timeout, sharedmemory, logfile):
		if type(hostname) != str or len(hostname) == 0:
			raise ValueError("invalid hostname: non-empty string required")
		if type(port) != int or port == 0:
			raise ValueError("invalid port: non-zero integer required")
		if type(namespace) != str or len(namespace) == 0:
			raise ValueError("invalid namespace: non-empty string required")
		try:
			self.hostname = hostname
			self.port = port
			self.namespace = namespace
			self.timeout = timeout
			self.sharedmemory = sharedmemory
			self.logfile = logfile
			self._log_stream = iris._LogFileStream._LogFileStream(logfile) if len(logfile)>0 else None
			with self._lock:
				server_address = (hostname, port)
				self._device = iris._Device._Device(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
				self._device._socket.settimeout(self.timeout/1000)
				self._device._socket.connect(server_address)
				self._in_message = iris._InStream._InStream(self)
				self._out_message = iris._OutStream._OutStream(self)
				# send MESSAGE_HANDSHAKE message
				self._out_message.wire._write_header(IRISConnection.MESSAGE_HANDSHAKE)
				protocol_bytes = struct.pack("<H",iris._Constant._Constant.PROTOCOL_VERSION)
				self._out_message.wire._set_raw_bytes(protocol_bytes)
				sequence_number = self._get_new_sequence_number()
				self._out_message._send(sequence_number)
				self._in_message._read_message_gateway(sequence_number)
				protocol_bytes = self._in_message.wire._get_raw_bytes(2)
				protocol = struct.unpack("<H", protocol_bytes)[0]
				if protocol<61:
					raise Exception("connection failed: IRIS xDBC protocol is not compatible")
				self._connection_info.protocol_version = protocol
				isunicode_bytes = self._in_message.wire._get_raw_bytes(2)
				self._connection_info._is_unicode = struct.unpack("<H", isunicode_bytes)[0]
				self._connection_info._set_server_locale(self._in_message.wire._get())
				# send MESSAGE_CONNECT message
				self._out_message.wire._write_header(IRISConnection.MESSAGE_CONNECT)
				# namespace
				self._out_message.wire._set(namespace)
				# encoded username
				if self._connection_info._is_unicode:
					username_encoded = self.__encodew(username)
				else:
					username_encoded = self.__encode(username)
				self._out_message.wire._set(username_encoded)
				# encoded password
				if self._connection_info._is_unicode:
					password_encoded = self.__encodew(password)
				else:
					password_encoded = self.__encode(password)
				self._out_message.wire._set(password_encoded)
				# OS username
				osuser = getpass.getuser()
				self._out_message.wire._set(osuser)
				# machine hostname
				thishostname = socket.gethostname()
				self._out_message.wire._set(thishostname)
				# application name
				appname = os.path.basename(__file__)
				self._out_message.wire._set(appname)
				# machine OS Info, not used anymore
				osinfo = bytearray(12)
				self._out_message.wire._set(osinfo)
				# HostName or IP for licensing
				thishostIP = socket.gethostbyname(hostname)
				self._out_message.wire._set(thishostIP)
				# EventClass -> null for now
				self._out_message.wire._set("")
				# Autocommit on -> 1 to start
				self._out_message.wire._set(1)
				# Isolation Level -> 1
				self._out_message.wire._set(1)
				# Feature Option -> 3 (fastInsert/fast Select) 
				self._out_message.wire._set(3)
				sequence_number = self._get_new_sequence_number()
				self._out_message._send(sequence_number)
				code = self._in_message._read_message_gateway(sequence_number)
				if code != -48:
					raise Exception(self._in_message.wire._get())
				server_version = self._in_message.wire._get()
				delimitedIds = self._in_message.wire._get()
				synchronousCommit = self._in_message.wire._get()
				supportedIsolationLevels = self._in_message.wire._get()
				srvJobNumber = self._in_message.wire._get()
				sqlEmptyString = self._in_message.wire._get()
				featureOption = self._in_message.wire._get()
			self._gateway = iris._PythonGateway._PythonGateway(self, None, None, None)
		except Exception as e:
			if self._device != None:
				self._device.close()
				self._device = None
			raise e
		return

	# Encodes the given Unicode string
	def __encodew(self, input_data):
		length = len(input_data)
		out_char = [None] * length
		i = 0
		while length > 0:
			length -= 1
			tint2 = ord(input_data[i])
			tint = (((ord(input_data[i]) ^ 0xA7) & 255) + length) & 255
			out_char[length] =  chr((tint2 & (255<<8)) | (((tint << 5) | (tint >> 3)) & 255))
			i += 1
		if i == 0:
			return None
		return ''.join(out_char)

	# Encodes the given Multi Byte string
	def __encode(self, input_data):
		length = len(input_data)
		out = [None] * length
		i = 0
		while length > 0:
			length -= 1
			tint = (((ord(input_data[i]) ^ 0xA7) & 255) + length) & 255
			tmp = (tint << 5) | (tint >> 3)
			tmp = tmp.to_bytes((tmp.bit_length() + 7) // 8, byteorder='little', signed=True)[0]
			out[length] = tmp
			i += 1
		return bytes(out)

	def _get_new_sequence_number(self):
		with self._lock_sequence_number:
			self._sequence_number += 2
			return self._sequence_number

	def _oref_registry_lookup(self, object):
		for key in self._oref_registry:
			if self._oref_registry[key] == object:
				return key
		for key in self._iris_object_proxy_map:
			if self._iris_object_proxy_map[key]() == object:
				return key
		return None

	def _map_local_object_to_oref(self, caller_in_message, caller_out_message, object):
		class_name = "%Net.Remote.Object"
		with self._lock:
			sequence_number = self._get_new_sequence_number()
			caller_out_message.wire._write_header(iris._Constant._Constant.MESSAGE_CREATE_OBJECT)
			caller_out_message.wire._set(1)
			caller_out_message.wire._set(class_name)
			caller_out_message._send(sequence_number)
			caller_in_message._read_message_gateway(sequence_number)
			oref = caller_in_message.wire._get()._oref
			if oref == "error":
				raise Exception(caller_in_message.wire._get())
		self._oref_registry[oref] = object
		self._oref_to_class_map[oref] = type(object).__name__
		with self._lock_closed_oref:
			self._iris_object_proxy_closed.append(oref)
		return oref

	def _map_local_object_from_oref(self, oref):
		created_proxy = False
		obj = self._oref_registry.get(oref)
		if obj == None:
			weak = self._iris_object_proxy_map.get(oref)
			if weak != None:
				obj = weak()
		if obj == None:
			obj = iris.IRISObject(self, oref)
			created_proxy = True
		if not created_proxy:
			with self._lock_closed_oref:
				self._iris_object_proxy_closed.append(oref)
		return obj

	def close_unused_oref(self, oref):
		with self._lock_closed_oref:
			self._iris_object_proxy_closed.append(oref)

	def get_closed_iris_objects(self):
		with self._lock_closed_oref:
			closed_iris_objects = self._iris_object_proxy_closed
			self._iris_object_proxy_closed = []
		return ",".join(closed_iris_objects)

	def get_parameter_listream(self, caller_in_message, caller_out_message, oref, instance):
		if oref.endswith("@%Library.ListOfDataTypes") or oref.endswith("@%Library.ListOfObjects"):
			if type(instance) != list:
				raise iris._GatewayException._GatewayException("Object is not a list")
			with self._lock:
				caller_out_message.wire._write_header(iris._Constant._Constant.MESSAGE_GET_LIST)
				caller_out_message.wire._set(oref)
				sequence_number = self._get_new_sequence_number()
				caller_out_message._send(sequence_number)
				code = caller_in_message._read_message_gateway(sequence_number)
				response = caller_in_message.wire._get()
				if response == "error":
					raise  iris._GatewayException._GatewayException(caller_in_message.wire._get())
				size = caller_in_message.wire._get()
				for i in range(size):
					if i>= len(instance):
						break
					value = caller_in_message.wire._get()
					if isinstance(value, iris._IRISOREF._IRISOREF):
						value = self._map_local_object_from_oref(value._oref)
					instance[i] = value
				return
		if oref.endswith("@%Library.GlobalBinaryStream"):
			if type(instance) != bytearray:
				raise iris._GatewayException._GatewayException("Object is not a bytearray")
			with self._lock:
				caller_out_message.wire._write_header(iris._Constant._Constant.MESSAGE_GET_STREAM)
				caller_out_message.wire._set(oref)
				sequence_number = self._get_new_sequence_number()
				caller_out_message._send(sequence_number)
				code = caller_in_message._read_message_gateway(sequence_number)
				response = caller_in_message.wire._get()
				if response == "error":
					raise  iris._GatewayException._GatewayException(caller_in_message.wire._get())
				size = caller_in_message.wire._get()
				pointer = 0
				buffer_size = len(instance)
				while (size>0):
					chunk_string = caller_in_message.wire._get()
					chunk_bytes = bytes(chunk_string, self._connection_info._locale)
					chunk_size = len(chunk_bytes)
					if pointer+chunk_size>buffer_size:
					   chunk_size = buffer_size-pointer
					instance[pointer:pointer+chunk_size] = chunk_bytes[0:chunk_size]
					pointer += chunk_size
					size -= chunk_size
					if pointer >= buffer_size:
						break
				return
		raise iris._GatewayException._GatewayException("Invalid argument for %setall(1): " + str(oref))
