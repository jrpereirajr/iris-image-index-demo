import collections.abc
import iris.IRISGlobalNode

class IRISIterator(collections.abc.Iterator, collections.abc.Iterable):

	VIEW_SUBSCRIPTS = 1
	VIEW_VALUES = 2
	VIEW_ITEMS = 3
	VIEW_NODES = 4
	VIEW_NODEITEMS = 5

	def __init__(self, view):
		self._irisnative = view._node._irisnative
		self._global_name = view._node._global_name
		self._subscripts = view._node._subscripts
		self._start = view._node._start
		self._stop = view._node._stop
		if self._start.is_marker():
			self._start._key = None
		if self._stop.is_marker():
			self._stop._key = None
		self._reversed = view._node._reversed
		self._view_type = view._view_type
		self._at_end = False

	def __iter__(self):
		return self

	def __next__(self):
		return self.next()

	def next(self):
		if self._at_end:
			raise StopIteration
		# deal with inclusiveness or call _nextNode
		if self._start._inclusive:
			dollar_data = self._irisnative.isDefined(self._global_name, *self._subscripts, self._start._key)
			if dollar_data == 0:
				key_value = self._irisnative._nextNode(self._reversed, self._global_name, *self._subscripts, self._start._key)
			elif dollar_data == 10:
				key_value = (str(self._start._key), None)
			else:
				value = self._irisnative.get(self._global_name, *self._subscripts, self._start._key)
				key_value = (str(self._start._key), value)
		else:
			key_value = self._irisnative._nextNode(self._reversed, self._global_name, *self._subscripts, self._start._key)
		# check if we are at end
		returned_value = key_value[0]
		if returned_value == None or len(returned_value) == 0:
			self._at_end = True
			raise StopIteration
		if self._stop._key is not None:
			if self._reversed:
				if not iris.IRISGlobalNode._follows(returned_value, self._stop._key):
					if not self._stop._inclusive or self._stop._key != returned_value:
						self._at_end = True
						raise StopIteration
			else:
				if not iris.IRISGlobalNode._follows(self._stop._key, returned_value):
					if not self._stop._inclusive or self._stop._key != returned_value:
						self._at_end = True
						raise StopIteration
		# save advancing pointer
		self._start = iris.IRISGlobalNode._point(returned_value, False)
		# return value
		if self._view_type == IRISIterator.VIEW_SUBSCRIPTS:
			return key_value[0]
		elif self._view_type == IRISIterator.VIEW_VALUES:
			return key_value[1]
		elif self._view_type == IRISIterator.VIEW_ITEMS:
			return key_value
		elif self._view_type == IRISIterator.VIEW_NODES:
			return self._irisnative.node(self._global_name, *self._subscripts, key_value[1])
		elif self._view_type == IRISIterator.VIEW_NODEITEMS:
			return (key_value[0], self._irisnative.node(self._global_name, *self._subscripts, key_value[1]))
		else:
			raise TypeError("UNrecognized view type")

	def startFrom(self, subscript):
		self._start = iris.IRISGlobalNode._point(subscript, False)
		return self

	def reversed(self):
		self._reversed = not self._reversed
		return self

	def subscripts(self):
		self._view_type = IRISIterator.VIEW_SUBSCRIPTS
		return self

	def values(self):
		self._view_type = IRISIterator.VIEW_VALUES
		return self

	def items(self):
		self._view_type = IRISIterator.VIEW_ITEMS
		return self

	def _state_(self):
		if self._reversed:
			left_sign = "[ " if self._stop._inclusive else "( "
			left_key = "None" if self._stop.is_marker() else str(self._stop._key)
			arrows = " <<< "
			right_key = "None" if self._start.is_marker() else str(self._start._key)
			right_sign = " ]" if self._start._inclusive else " )"
		else:
			left_sign = "[ " if self._start._inclusive else "( "
			left_key = "None" if self._start.is_marker() else str(self._start._key)
			arrows = " >>> "
			right_key = "None" if self._stop.is_marker() else str(self._stop._key)
			right_sign = " ]" if self._stop._inclusive else " )"
		return left_sign + left_key + arrows + right_key + right_sign
