import iris._ListWriter
import iris._MessageHeader

class _BufferWriter(iris._ListWriter._ListWriter):

	def __init__(self, locale, is_unicode):
		self.header = None
		super().__init__(locale, is_unicode)

	def _write_header(self, function_code):
		self.header = iris._MessageHeader._MessageHeader()
		self.header.buffer[12] = function_code[0]
		self.header.buffer[13] = function_code[1]
		self.offset = 0

	def _write_header_sysio(self, sysio_code):
		self.header = iris._MessageHeader._MessageHeader()
		self.header.buffer[12] = 64+sysio_code
		self.header.buffer[13] = 194
		self.offset = 0

	def _set_connection_info(self, connection_info):
		self._locale = connection_info._locale
		self._is_unicode = connection_info._is_unicode



