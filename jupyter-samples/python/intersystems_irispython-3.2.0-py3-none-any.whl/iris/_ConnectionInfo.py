import iris._Constant

class _ConnectionInfo(object):

	def __init__(self):
		self.protocol_version = iris._Constant._Constant.PROTOCOL_VERSION
		self._is_unicode = True
		self._locale = "latin-1"

	def _set_server_locale(self, locale):
		self._locale = _ConnectionInfo.__map_server_locale(locale)

	@staticmethod
	def __map_server_locale(locale):
		# we need to map IRIS locale literals to Python locale literals
		if locale == "Unicode" or locale.upper() == "LATIN1":
			return "latin_1"
		if locale.upper() == "LATIN2":
			return "iso8859_2"
		if locale.upper() == "LATINC":
			return "iso8859_5"
		if locale.upper() == "LATINA":
			return "iso8859_6"
		if locale.upper() == "LATING":
			return "iso8859_7"
		if locale.upper() == "LATINH":
			return "iso8859_8"
		if locale.upper() == "LATINT":
			return "iso8859_11"
		if locale.upper() == "LATIN9":
			return "iso8859_15"
		if locale.upper() == "CP1250":
			return "cp1250"
		if locale.upper() == "CP1251":
			return "cp1251"
		if locale.upper() == "CP1252":
			return "cp1252"
		if locale.upper() == "CP1253":
			return "cp1253"
		if locale.upper() == "CP1255":
			return "cp1255"
		if locale.upper() == "CP1256":
			return "cp1256"
		if locale.upper() == "CP1257":
			return "cp1257"
		if locale.upper() == "CP874":
			return "cp874"
		return locale


