class IRISReference(object):

	def __init__(self, value, type = object):
		self._value = value
		self._type = type

	def get_value(self):
		return self._value

	def set_value(self, value):
		self._value = value
		return
