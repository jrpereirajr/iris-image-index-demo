class _Device(object):

	def __init__(self, socket):
		self._socket = socket

	def close(self):
		self._socket.close()
